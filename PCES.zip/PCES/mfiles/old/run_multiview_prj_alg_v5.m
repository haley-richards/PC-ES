%--------------------------------------------------------------------------
%
% Run the projection algorithm
%   1. Perform a rigid transformation of the point cloud to the nominal cap
%
%--------------------------------------------------------------------------
function [elunlab] = run_multiview_prj_alg_v5(handles)
% clear
% clc
% close all
% load testdat
% % save testdat
% % clear
dbg_flg = 0;
addpath(genpath('S:/digihisto/Ethan/EKM_utility'))

%--------------------------------------------------------------------------
% Load the nominal cap
nomdat = load_nominal_cap(0);

%--------------------------------------------------------------------------
[colobj,tdat,eclks,cent0] = update_PLY_pts(handles);
allscans0.colobj  = colobj;
allscans0.tdat    = tdat;
allscans0.eclks   = eclks;
allscans0.elunlab = [];
 
%--------------------------------------------------------------------------
[allscans,nomdat] = bestfit_scan_to_nominal(allscans0,nomdat,0);
colobj = allscans.colobj;
%--------------------------------------------------------------------------
% Construct a spherical mesh described by angles
naz    = 7;
nel    = 6;
angmsh = construct_sphang_msh(naz,nel,0,20);


%--------------------------------------------------------------------------
% For each element of the angular mesh find the number of point cloud points
% within it and choice the scan with the most points as the one we keep
tic
locs     = double(allscans.colobj.Location);
rxys     = sqrt(sum(locs(:,1:2).^2,2));
pts_angs = [atan2(locs(:,2),locs(:,1)) atan(locs(:,3)./rxys)];
%-----
% Find points in each sector of each scan
np_psec = zeros(size(angmsh.angbds,1),1);
for n1 = 1:size(angmsh.angbds,1)
    is = find_points_insect(pts_angs,n1,angmsh);
    np_psec(n1) = length(is);
end

%--------------------------------------------------------------------------
% For each angular mesh element with sufficient points rotate it to be 
% aligned with z-axis, project into 2D, and click on electrodes
i_rots = find( np_psec > 0.7*max(np_psec));

if dbg_flg == 1
    figure;hold on
    set(gcf,'position',[1058         272         593         487])
    plot_angmesh(angmsh,i_rots,[1 0],0.15)
    pcshow(colobj,'Markersize',100);
    title([num2str(length(i_rots)),' of ',num2str(size(angmsh.angbds,1))])
end

colobj0 = colobj;
elunlab = [];
for n = 1:length(i_rots)
    %----------------------------------------------------------------------
    az    = angmsh.angcnts(i_rots(n),1);
    el    = angmsh.angcnts(i_rots(n),2);
    r0    = 0.15;
    ndir0 = r0*[cos(az).*cos(el) sin(az).*cos(el) sin(el)]';
    %----------------------------------------------------------------------
    Rz   = Rotz(-az);
    Ry   = Roty(el-pi/2);
    colobj = colobj0;
    locs   = (Ry*Rz*(colobj0.Location'))';
    ndir   = (Ry*Rz*(ndir0));
    if ~isempty(elunlab)
        elunlab   = (Ry*Rz*(elunlab'))';
    end
    colobj = pointCloud(locs, 'Color', colobj.Color );
    
    if dbg_flg == 1
        figure;hold on
        set(gcf,'position',[1058         272         593         487])
        plot_angmesh(angmsh,i_rots(n),[1 0],0.15)
        pcshow(colobj0,'Markersize',100);
        figure;hold on
        set(gcf,'position',[1058         272         593         487])
        pcshow(colobj,'Markersize',100);
        plot3(ndir(1),ndir(2),ndir(3),'.r','markersize',20)
        ndir
        view(2)
    end
    %----------------------------------------------------------------------
    [elunlab_new]   = run_prj_alg_v3(colobj,elunlab,[num2str(n),' of ',num2str(length(i_rots))],0);

    %----------------------------------------------------------------------
    % Unrotate and add it to the unlabeled electrodes
    if ~isempty(elunlab)    
        elunlab       = (Rz'*Ry'*(elunlab'))';    
    end
    if ~isempty(elunlab_new)    
        elunlab_new   = (Rz'*Ry'*(elunlab_new'))';    
        elunlab       = [elunlab; elunlab_new];
    end
end
% Convert the unlabeled electrodes back to the original frame (not best
% fitting to the nominal data
T       = allscans.T;
A       = T(1:3,1:3);
t       = T(1:3,4);
elunlab = (A'*(elunlab' - repmat(t,1,size(elunlab,1))))';
elunlab = convert_pts_back(elunlab,handles,cent0);




