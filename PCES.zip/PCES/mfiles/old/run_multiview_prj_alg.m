%-------------------------------------------------------------------------------
%
% Run the projection algorithm
%
%-------------------------------------------------------------------------------
% function newtdats = run_multiview_prj_alg(colobj)
clear
clc
close all
load testdat
dbg_flg = 1;

%-------------------------------------------------------------------------------
[colobj,tdat,eclks,cent0] = update_PLY_pts(handles);

%-------------------------------------------------------------------------------
% Set parameters
fac_cnvh = 1.0; % Reduction factor of the convex hull
MS       = 200;
Ndirs    = 6;

%-------------------------------------------------------------------------------
% Take the points 3D and only keep those above the z = 0 mark
locs0 = double(colobj.Location);
cols0 = colobj.Color;
is1    = find( locs0(:,3) > 0);
locs  = locs0(is1,:);
cols  = cols0(is1,:);

%-------------------------------------------------------------------------------
% Take 90% of the convex hull to do image processing analysis on
K    = convhull(locs(:,1),locs(:,2));
bps_cnvh = locs(K,:);
in     = inpolygon(locs(:,1),locs(:,2),fac_cnvh*bps_cnvh(:,1),fac_cnvh*bps_cnvh(:,2));
is2    = find(in == 1);
locs   = locs(is2,:);
locs(:,3) = 0;
cols   = cols(is2,:);
prjobj = pointCloud(locs, 'Color', cols);    


%-------------------------------------------------------------------------------
% Get a several well-spaced points within the shape
[xm,ym] = meshgrid(linspace(min(fac_cnvh*bps_cnvh(:,1)),max(fac_cnvh*bps_cnvh(:,1)),100),...
    linspace(min(fac_cnvh*bps_cnvh(:,2)),max(fac_cnvh*bps_cnvh(:,2)),100));
xysmp  = [xm(:) ym(:)];
in     = inpolygon(xysmp(:,1),xysmp(:,2),fac_cnvh*bps_cnvh(:,1),fac_cnvh*bps_cnvh(:,2));
xysmp  = xysmp(in==1,:);
[IDX,C] = kmeans(xysmp, Ndirs);
% Get the closest point of the centers to the 3D point cloud
sampdirs = zeros(Ndirs,3);
for n = 1:Ndirs
    [tmp,i] = min(sqrt( (locs0(is1,1)-C(n,1)).^2+(locs0(is1,2)-C(n,2)).^2));
    sampdirs(n,:) = [C(n,:) locs0(is1(i),3)];
end
sampdirs = double(sampdirs);
%-------------------------------------------------------------------------------
% Convert the sample directions back to the original frame and convert them
% to azimuth and elevation angles
sampdirs0 = convert_pts_back(sampdirs,handles,cent0);
azels = zeros(Ndirs,2);
for n = 1:Ndirs
    azels(n,1) = atan2(sampdirs0(n,2),sampdirs0(n,1));
    azels(n,2) = atan2(sampdirs0(n,3),norm(sampdirs0(n,1:2)) );
end
az2        = str2double(get(handles.cur_az,'String'))*pi/180;
el2        = str2double(get(handles.cur_el,'String'))*pi/180;
dists      = sqrt(sum( (azels - repmat([az2 el2],size(azels,1),1)).^2,2));
[sds,sids] = sort(dists,'ascend');
azels      = azels(sids,:);

%-------------------------------------------------------------------------------
% Loop through all the directions, apply the image processing technique,
% and collect all the data
newtdats = [];
for n = 1:Ndirs   
    [colobj,tdat,eclks,cent0] = update_PLY_pts(handles,azels(n,:));
    [tdats] = run_prj_alg(colobj,[],dbg_flg);
    newtdats         = [newtdats; tdats];
    if dbg_flg == 1
        title(['Az=',num2str(round(azels(n,1)*180/pi)),' El=',num2str(round(azels(n,2)*180/pi))])
        drawnow
    end
end

%-------------------------------------------------------------------------------
% To check that it worked...
handles.eclks = (1.02*sampdirs0);
update_ptcld_plot(hObject,handles)

%-------------------------------------------------------------------------------
figure
set(gcf,'position',[258         213        1025         739])
hold on
pcshow(colobj,'Markersize',MS);
plot3(fac_cnvh*bps_cnvh(:,1),fac_cnvh*bps_cnvh(:,2),bps_cnvh(:,3)+0.01,'-r','linewidth',2)
plot3(1.01*sampdirs(:,1),1.01*sampdirs(:,2),1.01*sampdirs(:,3),'.m','markersize',20)
axis equal
view(2)


figure
set(gcf,'position',[258         213        1025         739])
hold on
pcshow(prjobj,'Markersize',MS);
plot(fac_cnvh*bps_cnvh(:,1),fac_cnvh*bps_cnvh(:,2),'-r','linewidth',2)
plot(C(:,1),C(:,2),'.m','markersize',20)
axis equal
view(2)



return


%-------------------------------------------------------------------------------
% Run circle center finding algorithm
dbg_flg = 1;
cents   = find_circ_cents(img_m,dbg_flg);

%---------------------------------------------------------------------------
% convert the centers from pixel space to projected 2D space
cent_m      = zeros(size(cents,1),2);
cent_m(:,1) = interp1(1:npx,xs,cents(:,1));
cent_m(:,2) = interp1(1:npx,ys,cents(:,2));

%-------------------------------------------------------------------------------
% Transform the centers to 3D space, i.e. find
newtdats = zeros(size(cents,1),3);
for n = 1:size(cents,1)
    %---------------------------------------------------------------------------
    [tmp,j] = min( (locs(:,1) - cent_m(n,1)).^2 + (locs(:,2) - cent_m(n,2)).^2);
    newtdats(n,:) = locs0(is1(is2(j)),:);
end

% axes(handles.mainax);
% hold on
% plot3(newtdats(:,1),newtdats(:,2),newtdats(:,3),'.g','markersize',24)




