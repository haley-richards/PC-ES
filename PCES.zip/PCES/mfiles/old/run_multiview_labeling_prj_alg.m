%-------------------------------------------------------------------------------
%
% Run the projection algorithm
%
%-------------------------------------------------------------------------------
function [labtdats,tdats0] = run_multiview_labeling_prj_alg(handles)
% clear
% clc
% close all
% load testdat
dbg_flg = 0;

%-------------------------------------------------------------------------------
tdats0    = handles.tdat;
newtdats0 = handles.newtdats;
azels     = handles.azels;
Ndirs     = size(azels,1);
if isfield(handles,'labtdats') == 0
    labtdats  = NaN*newtdats0(:,1);
else
    labtdats  = handles.labtdats;
end
sclf_ps   = [];

%-------------------------------------------------------------------------------
% Load the nominal cap
nomdat = load_nominal_cap(0);

%-------------------------------------------------------------------------------
% Loop through all the directions, apply the image processing technique,
% and collect all the data
for n = 1:Ndirs
    % Rotate the PLY file and points found to the current frame
    [colobj,tdat,eclks,cent0] = update_PLY_pts(handles,azels(n,:));
    
    %---------------------------------------------------------------------------
    % Check that the direction is sensical: If most of the points are
    % negative than we really want az+180. If it is flipped, change the
    % azimuth angle and re-transform the point cloud. 
    if median(double(colobj.Location(:,3))) < 0
        azels(n,1) = azels(n,1) +pi;
        [colobj,tdat,eclks,cent0] = update_PLY_pts(handles,azels(n,:));
    end
        
    %---------------------------------------------------------------------------
    % Rotate the points to the current view
    if size(newtdats0,1) > 0
        newtdats = rotate_general_pts(newtdats0,handles,azels(n,:));
    else
        newtdats = [];
    end
    
    %---------------------------------------------------------------------------
    % Get the best-fit nominal electrode positions    
    [Bout,elns,cnxs,sclf_ps] = bestfit_nomel_noplot(tdat,nomdat,colobj,sclf_ps);
    
    %---------------------------------------------------------------------------
    % Get new points
    [labtdats]   = run_prj_alg_labeling(colobj,newtdats,Bout,elns,cnxs,labtdats,dbg_flg);    
    % if dbg_flg == 1
    title(['(',num2str(n),'of',num2str(Ndirs),'): Az=',num2str(round(azels(n,1)*180/pi)),' El=',num2str(round(azels(n,2)*180/pi))])
    drawnow

    %---------------------------------------------------------------------------
    % Update the list of labeled targets
    %     invelns = zeros(257,1);
    %     for k = 1:length(elns)
    %         invelns(elns(k)) = k;
    %     end
    efounds = find( isnan(labtdats) == 0);
    for k = 1:length(efounds)
        tdats0(labtdats(efounds(k)),1:3) = newtdats0(efounds(k),1:3);
    end
end

