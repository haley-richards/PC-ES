%--------------------------------------------------------------------------
%
% Run the projection algorithm
%
%--------------------------------------------------------------------------
function [newtdats0,azels] = run_multiview_prj_alg_v4(handles)
% clear
% clc
% close all
% load testdat
dbg_flg = 0;

%--------------------------------------------------------------------------
[colobj,tdat,eclks,cent0] = update_PLY_pts(handles);

%--------------------------------------------------------------------------
% Set parameters
fac_cnvh = 1.0; % Reduction factor of the convex hull
MS       = 200;

%--------------------------------------------------------------------------
% Take the points 3D and only keep those above the z = 0 mark
locs0 = double(colobj.Location);
cols0 = colobj.Color;
is1    = find( locs0(:,3) > 0);
locs  = locs0(is1,:);
cols  = cols0(is1,:);

%--------------------------------------------------------------------------
% Take 90% of the convex hull to do image processing analysis on
K    = convhull(locs(:,1),locs(:,2));
bps_cnvh = locs(K,:);
in     = inpolygon(locs(:,1),locs(:,2),fac_cnvh*bps_cnvh(:,1),fac_cnvh*bps_cnvh(:,2));
is2    = find(in == 1);
locs   = locs(is2,:);
locs(:,3) = 0;
cols   = cols(is2,:);
prjobj = pointCloud(locs, 'Color', cols);


%--------------------------------------------------------------------------
% Choose the manually identified electrodes as the search directions, 
% along with their average. 
is_fnd   = find( (isnan(tdat(:,1)) == 0) );
sampdirs = tdat(is_fnd,:);
sampdirs = sampdirs ./ repmat(sqrt(sum(sampdirs.^2,2)),1,3);
Ndirs    = size(sampdirs,1);

%-------------------------------------------------------------------------------
% Convert the sample directions back to the original frame and convert them
% to azimuth and elevation angles
az_0 = str2double(get(handles.cur_az,'String'))*pi/180;  
el_0 = str2double(get(handles.cur_el,'String'))*pi/180;
    
sampdirs0 = convert_pts_back(sampdirs,handles,cent0);
azels = zeros(Ndirs,2);
for n = 1:Ndirs
    azels(n,1) = atan2(sampdirs0(n,2),sampdirs0(n,1))+(pi-pi/4);
    azels(n,2) = atan2(sampdirs0(n,3),norm(sampdirs0(n,1:2)) );
    %     % calculate the difference from the current
    %     diffs_az   = [(azels(n,1) - az_0) (azels(n,1) - (az_0+2*pi)) (azels(n,1) - (az_0-2*pi))];
    %     diffs_el   = [(azels(n,1) - el_0) (azels(n,1) - (el_0+2*pi)) (azels(n,1) - (el_0-2*pi))];
    %     [tmp,i]    = min(abs(diffs_az));
    %     azels(n,1) = diffs_az(i);
    %     [tmp,i]    = min(abs(diffs_el));
    %     azels(n,2) = diffs_el(i);
    %
end
is_fnd
sampdirs0
[az_0 el_0]*180/pi
azels*180/pi
% azels(:,2) = azels(:,2)*0;

[colobj,tdat,eclks,cent0] = update_PLY_pts(handles);
figure
hold on
pcshow(colobj,'Markersize',MS);
plot3(1.05*tdat(:,1),1.05*tdat(:,2),1.05*tdat(:,3),'.m','markersize',20)
axis equal
view(2)
    
% We want to rotate the target point to be aligned with the z-axis.
for n = 1:Ndirs
    % Rotate the PLY file and points found to the current frame
    [colobj,tdat,eclks,cent0] = update_PLY_pts(handles,azels(n,:));
    figure
    hold on
    pcshow(colobj,'Markersize',MS);
    plot3(1.05*tdat(is_fnd(n),1),1.05*tdat(is_fnd(n),2),1.05*tdat(is_fnd(n),3),'.m','markersize',20)
    plot3(1.1*[0 sampdirs(n,1)],1.1*[0 sampdirs(n,2)],1.1*[0 sampdirs(n,3)],'-r','linewidth',2)
    axis equal
    view(2)
    lbl_fmt_fig('X (mm)','Y (mm)','','','Z (mm)',12)
    azels3(n,1) = atan2(tdat(is_fnd(n),2),tdat(is_fnd(n),1));
    azels3(n,2) = atan2(tdat(is_fnd(n),3),norm(tdat(is_fnd(n),1:2)) );
    azels3(n,:)*180/pi
end

clear



%-------------------------------------------------------------------------------
% Loop through all the directions, apply the image processing technique,
% and collect all the data
newtdats0 = [];
for n = 1:Ndirs
    % Rotate the PLY file and points found to the current frame
    [colobj,tdat,eclks,cent0] = update_PLY_pts(handles,azels(n,:));
    %---------------------------------------------------------------------------
    % Check that the direction is sensical: If most of the points are
    % negative than we really want az+180. If it is flipped, change the
    % azimuth angle and re-transform the point cloud. 
    if median(double(colobj.Location(:,3))) < 0
        azels(n,1) = azels(n,1) +pi;
        [colobj,tdat,eclks,cent0] = update_PLY_pts(handles,azels(n,:));
    end
        
    if size(newtdats0,1) > 0
        newtdats = rotate_general_pts(newtdats0,handles,azels(n,:));
    else
        newtdats = [];
    end
    % Get new points
    if n == 1    
        ttl_str = ['Ave. Direction of registration electrodes (',num2str(n),' of ',num2str(Ndirs),')'];
    else
        ttl_str = ['Towards E',num2str(is_fnd(n-1)),' (',num2str(n),' of ',num2str(Ndirs),')'];
    end
    [tdats]   = run_prj_alg_v3(colobj,newtdats,ttl_str,dbg_flg);
    if size(tdats,1) > 0
        tdats     = convert_pts_back(tdats,handles,cent0,azels(n,:));
        % Add the points (in the original frame) to the full set of points
        newtdats0         = [newtdats0; tdats];
    end
    % if dbg_flg == 1
    % title(['Az=',num2str(round(azels(n,1)*180/pi)),' El=',num2str(round(azels(n,2)*180/pi))])
    drawnow
    % end
end

% %-------------------------------------------------------------------------------
% % To check that it worked...
% handles.eclks = (1.02*sampdirs0);
% update_ptcld_plot(hObject,handles)

% %-------------------------------------------------------------------------------
% figure
% set(gcf,'position',[258         213        1025         739])
% hold on
% az2        = str2double(get(handles.cur_az,'String'))*pi/180;
% el2        = str2double(get(handles.cur_el,'String'))*pi/180;
% [colobj,tdat,eclks,cent0] = update_PLY_pts(handles,[az2 el2]);
% newtdats = rotate_general_pts(newtdats0,handles,[az2 el2]);
% pcshow(colobj,'Markersize',MS);
% plot3(1.01*newtdats(:,1),1.01*newtdats(:,2),1.01*newtdats(:,3),'.m','markersize',20)
% axis equal
% view(2)
