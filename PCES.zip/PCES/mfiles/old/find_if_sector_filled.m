%-------------------------------------------------------------------------------
% 
% A sector from the angular mesh is defined by a lower and upper azimuth and 
% elevation angle. This function is written for finding if a ton a points
% (potentially millions) are filling a sector. So, what we do is breakup
% the the sector into a bunch of little sectors and 
% 
%-------------------------------------------------------------------------------
function perc_fill = find_if_sector_filled(pts_angs,n,angmsh)

naz     = 10;
nel     = 10;
azb     = angmsh.angbds(n,1:2);
elb     = angmsh.angbds(n,3:4);
azs     = linspace(azb(1),azb(2),naz);
els     = linspace(elb(1),elb(2),nel);
angbds  = zeros((naz-1)*(nel-3)+2,4);
k      = 1;
for n1 = 1:(naz-1)
    for n2 = 2:(nel-2)
        %-----------------------------------------------------------------------
        % Set the angle bounds
        angbds(k,:)  = [azs(n1) azs(n1+1)  els(n2) els(n2+1)];
        %-----------------------------------------------------------------------
        k = k+1;
    end
end
angmsh_mini.angbds = angbds;

%-------------------------------------------------------------------------------
% Loop through each sector and see if there are any points
fillflag = zeros(size(angmsh_mini.angbds,1),1);
for n = 1:size(angmsh_mini.angbds,1)
    if ~isempty(find_points_insect(pts_angs,n,angmsh_mini))
        fillflag(n) = 1;
    end    
end
perc_fill = sum(fillflag)/size(angmsh_mini.angbds,1)*100;
disp(['Percent filled: ',num2str(round(perc_fill,1)),'%'])


% if perc_fill > fill_thresh
%     filled = 1;
% else
%     filled = 0;
% end