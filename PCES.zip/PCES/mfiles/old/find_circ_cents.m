%-------------------------------------------------------------------------------
%
% Run circle center finding algorithm
%
%-------------------------------------------------------------------------------
function [centers,template] = find_circ_cents(img_m,template,dbg_flg)
% save testdata
% clear

% clear
% clc
% close all
% load testdata

meth_num = 2;

%-------------------------------------------------------------------------------
if meth_num == 1
    %-------------------------------------------------------------------------------
    % Find circles
    % circ_siz        = [5 12];
    circ_siz        = [8 20];
    % circ_siz        = [floor(25/2) ceil(35/2)];
    [centers,radii] = imfindcircles(img_m,circ_siz,'ObjectPolarity','bright');% ,'Sensitivity',0.95);
    % [centersBright,radiiBright,metricBright] = imfindcircles(img2d,[6 12], ...
    %     'ObjectPolarity','dark','Sensitivity',0.92,'EdgeThreshold',0.1);
    
    if dbg_flg == 1
        figure
        imagesc(img_m)
        colormap gray
        hold on
        h = viscircles(centers,radii);
        axis equal
        set(gca, 'YDir','normal')
    end
    
    %---------------------------------------------------------------------------
    % Use template matching
elseif meth_num == 2
    %---------------------------------------------------------------------------
    % Plot the image and pick an electrode as the template
    if (nargin < 2) || (isempty(template) == 1)
        figure
        set(gcf,'position',[257         124        1198         825])
        imagesc(img_m)
        colormap gray
        hold on
        axis equal
        set(gca, 'YDir','normal')
        title('Pick 5 Templates: 1) the top left and 2) the bottom right of an electrode for template matching')
        for n = 1:5
            [x1,y1,butt] = ginputWhite(1);
            title('Pick 2) the bottom right of an electrode for template matching')
            [x2,y2,butt] = ginputWhite(1);
            template{n} = img_m(floor(y2):ceil(y1),:);
            template{n} = template{n}(:,floor(x1):ceil(x2));
            plot([x1 x2 x2 x1 x1],[y2 y2 y1 y1 y2],'-')
        end
    end
    % Get rid of NaNs
    img_v     = img_m(:);
    is        = find(isnan(img_v)==1);
    img_v(is) = 0;
    img_m2    = reshape(img_v,size(img_m,1),size(img_m,2));
    
    for n = 1:5
        C{n} = normxcorr2(template{n}/255,img_m2/255);
    end
    %     figure
    %     for n = 1:5
    %         C{n} = normxcorr2(template{n}/255,img_m2/255);
    %         subplot(2,3,n)
    %         imagesc(C{n})
    %         axis equal
    %         set(gca, 'YDir','normal')
    %     end
    %
    if dbg_flg == 1
        imagesc(img_m)
        colormap gray
        hold on
        axis equal
        set(gca, 'YDir','normal')
    end        
    centers = [];
    % save testdat_circ_cents
    dsttol = 50;
    for n = 1:5
        tol = quantile(C{n}(:),0.9995);
        [ypeak, xpeak] = find(C{n} > tol);
        ypeak = ypeak-size(template{n},1)/2;
        xpeak = xpeak-size(template{n},2)/2;
        %         Dvals = 0*num_elecs;
        %         for k = 1:length(num_elecs)
        %             [idx,Cs{k},sumd,Ds] = kmeans([xpeak ypeak],num_elecs(k));
        %             sumds(k) = min(sumd);
        %         end
        %         figure
        %         plot(sumds)
        %         set(gca,'yscale','log')
        %         clear
        % is    = find( sumds < 5);
        targs = [xpeak ypeak];
        targs_av = avnear_pts(targs,dsttol);
        % targs = Cs{is(1)};
        %         plot(num_elecs,Dvals)
        %         set(gca,'yscale','log')
        
        disp(['Template ',num2str(n),': ',num2str(size(xpeak,1)),', ',num2str(size(targs_av,1)),' av points'])
        if dbg_flg == 1
            plot(targs(:,1),targs(:,2),'.','markersize',6)
            plot(targs_av(:,1),targs_av(:,2),'o','markersize',6)
        end
        centers = [centers; targs_av];
    end
    centers = avnear_pts(centers,dsttol);
    
    
    %     imgbw = imbinarize(img_m/255,'global');
    %     circ_siz        = [8 20];
    %     % circ_siz        = [floor(25/2) ceil(35/2)];
    %     [centers,radii] = imfindcircles(imgbw,circ_siz,'ObjectPolarity','bright','Sensitivity',0.85);
    %
    %     figure
    %     imagesc(imgbw)
    %     h = viscircles(centers,radii);
    %     colormap gray
    %     hold on
    %     axis equal
    %     set(gca, 'YDir','normal')
    %     %---------------------------------------------------------------------------
    %     C = normxcorr2(template/255,img_m/255);
    
end