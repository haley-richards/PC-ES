function [centroids_final]=find_centers(Im_0)
%This function automates the electrode selection
%Im is uint 8. Alternatively 
%convert to type double
Im_0=rgb2gray(Im_0);

Im=(im2double(Im_0))./255;
figure
nrows=size(Im, 1);
ncols=size(Im, 2)
window=Im((nrows/2-200):(nrows/2+200), (ncols/2-200):(ncols/2+200));
imagesc(window)
title('draw radius of electrode');
% %adjust contrast
low_in=min(min(Im));
high_in=max(max(Im));
Im= imadjust(Im,[low_in high_in]);
% %find radius 
line = drawline;
r=round(abs(sum(line.Position(1, :)-line.Position(2, :))))-10;
%create structuring element
se = strel('disk', r);
%open and close image
Io = imopen(Im,se);
% figure
% imshow(Io)
% title('Opening')
Ie = imerode(Im,se);
%morphological reconstruction, fill holes 
Iobr = imreconstruct(Ie,Im);
Iobr = imfill(Iobr,'holes');
% figure
% imshow(Iobr)
% title('Opening-by-Reconstruction')
%create adaptive threshold 
T=Iobr; T = adaptthresh(Iobr, .5, 'NeighborhoodSize', 2*floor(size(Iobr)/16)+1, 'Statistic', 'mean');
%get rid of background
T(T<0.3)=1;
BW = imbinarize(Ie,T);
% imshow(BW)
% title('BW map 1')
%label connected regions 
CC = bwconncomp(BW);
Centroids = regionprops(CC,'Centroid');
Circ= regionprops(CC,'Circularity');
Area=regionprops(CC,'Area');
%get region properties
centroid_table=struct2table(Centroids);
circ_table=struct2table(Circ);
area_table=struct2table(Area);
circ=table2array(circ_table);
areas=table2array(area_table);
centroid_coords=table2array(centroid_table);
%get rid of regions out of desired area range, and without enough
%circularity
count=1;
for i=1:CC.NumObjects
      if areas(i) >100 && areas(i)< 4000
        if circ(i) > .5 
            
        areas_final(count)=areas(i);
        centroids_final(count, :)=centroid_coords(i, :);
         
         for j=1:(count-1)
            if norm(centroids_final(count, :)-centroids_final(j, :))<3*r
               centroids_final(count, :)=0;
            end
            
         end
        count=count+1;
        
        end
    end
end
% figure
% imagesc(Im_0)
% colormap(gca, gray)
% hold on
% plot(centroids_final(:, 1), centroids_final(:, 2), 'r.', 'MarkerSize', 20 )
% hold off
%crosscorrelate with all possible centers
sum_im=zeros(size(Im));
for i=1:max(size(centroids_final))
    if centroids_final(i, 1)==0
        continue
    else
        if centroids_final(i, 1)>20 && centroids_final(i, 1)<(size(Im, 1)-20)  && centroids_final(i, 2) >20 && centroids_final(i, 2)<(size(Im, 2)-20); 
    template=Im((centroids_final(i, 1)-20):(centroids_final(i, 1)+20),(centroids_final(i, 2)-20):(centroids_final(i, 2)+20));
    c = xcorr2(template ,Im);
    c=c(21:(end-20), 21:(end-20));
    sum_im=sum_im+c;
     count=count+1;
        end
    end
end

sum_im(:, :)=sum_im(end:-1:1, end:-1:1);
sum_im=imsharpen(sum_im, 'Threshold', .05);
% figure
% surf(sum_im)
% title('autocorrelation')
%repeat process again on autocorrelated image
Im=(im2double(sum_im))./max(max(sum_im));
if r>10
r=r-10;
else
    r=r;
end
se = strel('disk', r);
Io = imopen(Im,se);
% figure
% imshow(Io)
% title('Opening')
Ie = imerode(Im,se);
low_in=.6;
high_in=(max(max(Ie)))
Im= imadjust(Ie,[low_in high_in]);
Iobr = imreconstruct(Ie,Im);
% figure
% imshow(Iobr)
% title('Opening-by-Reconstruction')
Iobr = imfill(Iobr,'holes');
%change thresholds to favor pixels in low contrast regions only
T = adaptthresh(Iobr, .1, 'NeighborhoodSize', 2*floor(size(Iobr)/32)+1, 'Statistic', 'mean');
T(T<0.2)=1;
BW = imbinarize(Ie,T);
% imshow(BW)
% title('BW map 2 (autocorrelation)')
CC = bwconncomp(BW);
Centroids = regionprops(CC,'Centroid');
Circ= regionprops(CC,'Circularity');
Area=regionprops(CC,'Area');
%get rid of areas that are either too small or too big
centroid_table=struct2table(Centroids);
circ_table=struct2table(Circ);
area_table=struct2table(Area);
circ=table2array(circ_table);
areas=table2array(area_table);
centroid_coords=table2array(centroid_table);
count=(size(centroids_final, 1));
for i=1:CC.NumObjects
      if areas(i) >10 && areas(i)< 10000
        if circ(i) > .25    
        areas_final(count)=areas(i);
        centroids_final(count, :)=centroid_coords(i, :);
         for j=1:(count-1)
            if norm(centroids_final(count, :)-centroids_final(j, :))<2*(r+10)
               centroids_final(count, :)=0;
            end 
         end
        count=count+1;
        end
    end
end
imagesc(Im_0)
colormap(gca, gray)
hold on
plot(centroids_final(:, 1), centroids_final(:, 2), 'r.', 'MarkerSize', 20 )
legend('labeled centers')
title('final labels')
hold off