%-------------------------------------------------------------------------------
%
% Run the projection algorithm
%
%   pts0     - 3D electrodes found (without labels initially)
%   labtdats0- Size equal to Bout0, gives the electrode number (if one has
%              already been found) for each Bout0 point
%   
%   Bout0    - 3D electrodes from a nominal EEG cap
%   elns     - Electrode number 
%   cnxs     - Connections to local electrodes of nominal EEG cap
% 
%-------------------------------------------------------------------------------
function [labtdats0] = run_prj_alg_labeling(colobj,pts0,Bout0,elns0,cnxs,labtdats0,dbg_flg)
% clear
% clc
% close all
% load testdat


%--------------------------------------------------------------------------
% Take the points 3D and only keep those above the z = 0 mark
locs0 = double(colobj.Location);
cols0 = colobj.Color;
is1   = find( locs0(:,3) > 0);
locs  = locs0(is1,:);
cols  = cols0(is1,:);
if size(pts0,1) > 0
    is1b     = find( pts0(:,3) > 0);
    pts      = pts0(is1b,:);
    labtdats = labtdats0(is1b);    
end
if size(Bout0,1) > 0
    is1c   = find( Bout0(:,3) > 0);
    Bout   = Bout0(is1c,:);
    elns   = elns0(is1c);
    
    
    % Keep only edges that are attached to two valid electrodes
    kis  = [];
    for n = 1:size(cnxs,1)
        if ~isempty(intersect(cnxs(n,1),elns)) && ~isempty(intersect(cnxs(n,2),elns))
            kis  = [kis; n];
        end
    end
    cnxs = cnxs(kis,:);
    % Get the inverse of the electrode numbering
    invelns = zeros(257,1);
    for n = 1:length(elns)
        invelns(elns(n)) = n;
    end
    %     disp('Elec labels, that are not in the connections')
    %     setdiff(elns,[cnxs(:,1); cnxs(:,2)])
    %     disp('Connection electrodes that are not in the labels')
    %     setdiff([cnxs(:,1); cnxs(:,2)],elns)
end

%-------------------------------------------------------------------------------
% Update the nominal electrodes to match the ones that have been labeled.
%   pts0     - 3D electrodes found (without labels initially)
%   labtdats0- Size equal to Bout0, gives the electrode number (if one has
%              already been found) for each Bout0 point
%   
%   Bout0    - 3D electrodes from a nominal EEG cap
%   elns     - Electrode number 
%   cnxs     - Connections to local electrodes of nominal EEG cap
%   efounds  - The electrodes that have been identified from pts0, which
%              are stored in labtdats0
%   invelns  - ith index of invelns corresponds to the ith electrode, and its
%              value at the ith index is the corresponding Bout index
% if invelns(labtdats(efounds(n))) = 0, that means there is no Bout
% electrode 
save testdat
efounds = find( isnan(labtdats) == 0);
for n = 1:length(efounds)
    try        
        Bout(invelns(labtdats(efounds(n))),1:3) = pts(efounds(n),1:3);
    catch        
        disp('Intersect larger set of nominal electrodes')
        intersect(efounds(n),elns0)
        disp('Intersect larger smaller set of nominal electrodes')
        intersect(efounds(n),elns)
        [n labtdats(efounds(n)) invelns(labtdats(efounds(n))) efounds(n)]
        % error('stop')
    end
end


%-------------------------------------------------------------------------------
% Take 90% of the convex hull to do image processing analysis on
K    = convhull(locs(:,1),locs(:,2));
in   = inpolygon(locs(:,1),locs(:,2),0.9*locs(K,1),0.9*locs(K,2));
is2   = find(in == 1);
locs = locs(is2,:);
cols = cols(is2,:);
cols = mean(cols,2);

%-------------------------------------------------------------------------------
% Construct a meshgrid of the locations values
npx = 1000;
xs      = linspace(min(locs(:,1)),max(locs(:,1)),npx);
ys      = linspace(min(locs(:,2)),max(locs(:,2)),npx);
[xm,ym] = meshgrid(xs,ys);
xys     = [xm(:) ym(:)];

%-------------------------------------------------------------------------------
% Interpolate onto the meshgrid
F     = scatteredInterpolant(locs(:,1:2),cols,'linear','none');
img_v = F(xys);
img_m = reshape(img_v,size(xm,1),size(xm,2));
%-------------------------------------------------------------------------------
% Interpolate the points into the image frame
if size(pts0,1) > 0
    pts_m(:,1) = interp1(xs,1:npx,pts(:,1));
    pts_m(:,2) = interp1(ys,1:npx,pts(:,2));
else
    pts_m = [];
end
if size(Bout0,1) > 0
    Bout_m(:,1) = interp1(xs,1:npx,Bout(:,1));
    Bout_m(:,2) = interp1(ys,1:npx,Bout(:,2));
else
    Bout_m = [];
end

if dbg_flg == 1
    imagesc(img_m)
    set(gca, 'YDir','normal')
    colormap(gray)
    axis equal
    drawnow
end
%--------------------------------------------------------------------------
% Run circle center finding algorithm
[labtdats] = find_labels_in_prj(img_m,pts_m,Bout_m,elns,invelns,cnxs,labtdats,dbg_flg);

labtdats0(is1b) = labtdats;



%-------------------------------------------------------------------------------
%-------------------------------------------------------------------------------
%-------------------------------------------------------------------------------
%-------------------------------------------------------------------------------
%
% Run circle center finding algorithm
%
%-------------------------------------------------------------------------------
function [labtdats] = find_labels_in_prj(img_m,pts_m,Bout_m,elns,invelns,cnxs,labtdats,dbg_flg)
% save testdata
% clear

% clear
% clc
% close all
% load testdata

%---------------------------------------------------------------------------
% Plot the image and pick an electrode as the template
figure
set(gcf,'position',[257         124        1198         825])
plot_update_tmp(img_m,pts_m,Bout_m,invelns,cnxs,labtdats)
title('Left Click for close pairs of points, 2nd Click a Nominal EEG cap pont (cyan) and its matching Electrode (red), and Right click to finish')
pause(0.3)
butt    = 1;
while (butt == 1) || (butt == 2)
    % Pick the nominal point
    title('Left Click if the pair are close, 2nd Click for Nominal EEG cap pont (cyan), ')
    [x1,y1,butt] = ginputWhite(1);
    if butt == 1
        % Find the closest Nominal EEG cap (Bout) point to x1,y1
        [tmp,i1] = min(sum( (Bout_m - repmat([x1 y1],size(Bout_m,1),1)).^2,2));
        % Find the closest marked electrode (pts_m) point to x1,y1
        [tmp,i2] = min(sum( (pts_m - repmat([x1 y1],size(pts_m,1),1)).^2,2));
        % Label the Bout index by the corresponding electrode label
        labtdats(i2) = elns(i1);
        Bout_m(i1,:) = pts_m(i2,:);
    elseif butt == 2
        plot(x1,y1,'.g','markersize',26)
        title('Pick its matching Electrode cap pont (red) and Right click to finish')
        [x2,y2,butt] = ginputWhite(1);
        if butt == 1
            plot(x2,y2,'.g','markersize',26)
            % Find the closest Nominal EEG cap (Bout) point to x1,y1
            [tmp,i1] = min(sum( (Bout_m - repmat([x1 y1],size(Bout_m,1),1)).^2,2));
            % Find the closest marked electrode (pts_m) point to x1,y1
            [tmp,i2] = min(sum( (pts_m - repmat([x2 y2],size(pts_m,1),1)).^2,2));
            % Label the Bout index by the corresponding electrode label
            labtdats(i2) = elns(i1);
            Bout_m(i1,:) = pts_m(i2,:);
        end
    end
    plot_update_tmp(img_m,pts_m,Bout_m,invelns,cnxs,labtdats)
    

end


function plot_update_tmp(img_m,pts_m,Bout_m,invelns,cnxs,labtdats)

clf
imagesc(img_m)
hold on
if size(Bout_m,1) > 0       
    plot(Bout_m(:,1),Bout_m(:,2),'.c','markersize',12)        
    plot([Bout_m(invelns(cnxs(:,1)),1) Bout_m(invelns(cnxs(:,2)),1)]',[Bout_m(invelns(cnxs(:,1)),2) Bout_m(invelns(cnxs(:,2)),2)]','-c','markersize',12)        
end
if size(pts_m,1) > 0
    is = find(isnan(labtdats)==0);
    inotlab = setdiff(1:length(labtdats),is);
    plot(pts_m(inotlab,1),pts_m(inotlab,2),'.r','markersize',18)
    plot(pts_m(is,1),pts_m(is,2),'.g','markersize',26)
end

legend('Image','Unlabeled','Nominal Unmatched','Nominal Matched','location','southeast')
colormap gray
hold on
axis equal
set(gca, 'YDir','normal')
