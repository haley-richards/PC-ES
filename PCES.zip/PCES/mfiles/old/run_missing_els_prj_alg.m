%--------------------------------------------------------------------------
%
% Run the projection algorithm
%
%--------------------------------------------------------------------------
% function [labtdats,tdats0] = run_missing_els_prj_alg(handles)
% save testdat_missing
clear
clc
close all
load testdat_missing
dbg_flg = 0;

tdats0    = handles.tdat;
i_elmis   = find( isnan(tdats0(:,1)) == 1);
i_elmis   = i_elmis( i_elmis <= 256);

%--------------------------------------------------------------------------
% Load the nominal cap
sclf_ps   = [];
nomdat = load_nominal_cap(0);
[Bout] = bestfit_nomel_noplot_fullset(tdats0,nomdat);

%--------------------------------------------------------------------------
% Keep looking till all are found
while ~isempty(i_elmis)
    %----------------------------------------------------------------------
    % Find/update the missing electrodes
    i_elmis   = find( isnan(tdats0(:,1)) == 1);
    i_elmis   = i_elmis( i_elmis <= 256);
    
    %----------------------------------------------------------------------
    azels(1) = atan2(Bout(i_elmis(1),2),Bout(i_elmis(1),1));
    azels(2) = atan2(Bout(i_elmis(1),3),norm(Bout(i_elmis(1),1:2)) );
    
    [colobj,tdat,eclks,cent0] = update_PLY_pts(handles,azels);
    newtdats = tdat;
    labtdats = 1:258;
    %----------------------------------------------------------------------
    % Get the best-fit nominal electrode positions
    [Bout,elns,cnxs,sclf_ps] = bestfit_nomel_noplot(tdat,nomdat,colobj,sclf_ps);
    
    %----------------------------------------------------------------------
    % Get new points    
    [newp,newlabtdats] = run_prj_alg_find_and_labeling(colobj,newtdats,Bout,elns,cnxs,labtdats,dbg_flg);
    % if dbg_flg == 1
    drawnow
    
    %----------------------------------------------------------------------
    % Update the list of labeled targets
    if size(newp,1) > 0
        newtdats     = convert_pts_back(newp,handles,cent0,azels);
        disp(['New labeled points: ',num2str(newlabtdats)])
        tdats0(newlabtdats,:) = newtdats;
    end
    
end
