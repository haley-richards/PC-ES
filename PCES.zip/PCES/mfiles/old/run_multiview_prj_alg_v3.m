%-------------------------------------------------------------------------------
%
% Run the projection algorithm
%
%-------------------------------------------------------------------------------
% function [newtdats0,azels] = run_multiview_prj_alg_v3(handles)
clear
clc
close all
load testdat handles
dbg_flg = 0;

%-------------------------------------------------------------------------------
% Load the nominal cap
nomdat = load_nominal_cap(0);

%-------------------------------------------------------------------------------
tdat   = handles.tdat;
colobj = handles.colobj;
[tdat,nomdat,colobj,bestsclf,Top] = bestfitting_of_nominal_elecs_to_nomframe_func(tdat,nomdat,colobj,0);

%-------------------------------------------------------------------------------
% Construct a spherical mesh described by angles
naz    = 7;
nel    = 6;
angmsh = construct_sphang_msh(naz,nel,1);

%-------------------------------------------------------------------------------
%-------------------------------------------------------------------------------
% Find sectors that have sufficient points within it.
%-------------------------------------------------------------------------------
% Get the angles of all the point cloud points
locs  = double(colobj.Location);
rxys  = sqrt(sum(locs(:,1:2).^2,2));
rs    = sqrt(sum(locs(:,1:3).^2,2));
angs  = [atan2(locs(:,2),locs(:,1)) atan(locs(:,3)./rxys)];
secas = calc_angmsh_areas(angmsh);
%-------------------------------------------------------------------------------
% Find points in each sector of each scan. Find sectors that appear filled.
% The area of the sector I'm assuming is the spherical surface integral with a 
% constant radius. The point cloud should at a 1 mm resolution. So if its a
% 100 mm^2 area I expect about 100 points
perfill = zeros(size(angmsh.angbds,1),1);
for n = 1:size(angmsh.angbds,1)
    perfill(n) = find_if_sector_filled(angs,n,angmsh);   
end
i_angs     = find( perfill > 50);
r0         = median(rs);

figure
hold on
pcshow(colobj)
plot3(nomdat.eeg_mps(:,1),nomdat.eeg_mps(:,2),nomdat.eeg_mps(:,3),'.c','markersize',16)
plot3(tdat(:,1),tdat(:,2),tdat(:,3),'.r','markersize',16)
plot_angmesh_r0_inds(angmsh,1.2*r0,i_angs);


%-------------------------------------------------------------------------------
% Loop through all the directions, apply the image processing technique,
% and collect all the data
newtdats0 = [];
for n = 1:length(i_angs)
    %---------------------------------------------------------------------------
    % Project onto the nth direction and produce the image
    prj_colobj_indir(colobj,tdat,i_angs(n),angmsh,1)
    
    %
    %
    %     % Rotate the PLY file and points found to the current frame
    %     [colobj,tdat,eclks,cent0] = update_PLY_pts(handles,azels(n,:));
    %     %---------------------------------------------------------------------------
    %     % Check that the direction is sensical: If most of the points are
    %     % negative than we really want az+180. If it is flipped, change the
    %     % azimuth angle and re-transform the point cloud.
    %     if median(double(colobj.Location(:,3))) < 0
    %         azels(n,1) = azels(n,1) +pi;
    %         [colobj,tdat,eclks,cent0] = update_PLY_pts(handles,azels(n,:));
    %     end
    %
    %     if size(newtdats0,1) > 0
    %         newtdats = rotate_general_pts(newtdats0,handles,azels(n,:));
    %     else
    %         newtdats = [];
    %     end
    %     % Get new points
    %     [tdats]   = run_prj_alg_v2(colobj,newtdats,dbg_flg);
    %     if size(tdats,1) > 0
    %         tdats     = convert_pts_back(tdats,handles,cent0,azels(n,:));
    %         % Add the points (in the original frame) to the full set of points
    %         newtdats0         = [newtdats0; tdats];
    %     end
    %     % if dbg_flg == 1
    %     title(['Az=',num2str(round(azels(n,1)*180/pi)),' El=',num2str(round(azels(n,2)*180/pi))])
    %     drawnow
    %     % end
end

return
% %-------------------------------------------------------------------------------
% % To check that it worked...
% handles.eclks = (1.02*sampdirs0);
% update_ptcld_plot(hObject,handles)

%-------------------------------------------------------------------------------
figure
set(gcf,'position',[258         213        1025         739])
hold on
az2        = str2double(get(handles.cur_az,'String'))*pi/180;
el2        = str2double(get(handles.cur_el,'String'))*pi/180;
[colobj,tdat,eclks,cent0] = update_PLY_pts(handles,[az2 el2]);
newtdats = rotate_general_pts(newtdats0,handles,[az2 el2]);
pcshow(colobj,'Markersize',MS);
plot3(1.01*newtdats(:,1),1.01*newtdats(:,2),1.01*newtdats(:,3),'.m','markersize',20)
axis equal
view(2)
