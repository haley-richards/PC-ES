%-------------------------------------------------------------------------------
%
% Run circle center finding algorithm
%
%-------------------------------------------------------------------------------
function [centers] = find_circ_cents_v2(img_m,pts_m,dbg_flg)
% save testdata
% clear

% clear
% clc
% close all
% load testdata

%---------------------------------------------------------------------------
% Plot the image and pick an electrode as the template
figure
set(gcf,'position',[257         124        1198         825])
imagesc(img_m)
hold on
if size(pts_m,1) > 0
    plot(pts_m(:,1),pts_m(:,2),'.r','markersize',12)
end
colormap gray
hold on
axis equal
set(gca, 'YDir','normal')
title('Pick unmarked electrodes')
butt    = 1;
centers = [];
while (butt == 1) || (butt == 2)
    [x1,y1,butt] = ginputWhite(1);
    if butt == 1        
        plot(x1,y1,'.g','markersize',18)
        centers = [centers; x1,y1];
    elseif butt == 2
        [tmp,i] = min( sum( (centers - repmat([x1 y1],size(centers,1),1)).^2,2));
        centers(i,:) = [];
        clf
        imagesc(img_m)
        hold on
        if size(pts_m,1) > 0
            plot(pts_m(:,1),pts_m(:,2),'.r','markersize',18)
        end
        if size(centers,1) > 0 
            plot(centers(:,1),centers(:,2),'.g','markersize',18)
        end        
        % colormap gray
        hold on
        axis equal
        set(gca, 'YDir','normal')        
    end
end


