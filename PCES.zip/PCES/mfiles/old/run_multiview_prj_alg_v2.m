%-------------------------------------------------------------------------------
%
% Run the projection algorithm
%
%-------------------------------------------------------------------------------
function [newtdats0,azels] = run_multiview_prj_alg_v2(handles)
% clear
% clc
% close all
% load testdat
dbg_flg = 0;

%-------------------------------------------------------------------------------
[colobj,tdat,eclks,cent0] = update_PLY_pts(handles);

%-------------------------------------------------------------------------------
% Set parameters
fac_cnvh = 1.0; % Reduction factor of the convex hull
MS       = 200;
Ndirs    = 6;

%-------------------------------------------------------------------------------
% Take the points 3D and only keep those above the z = 0 mark
locs0 = double(colobj.Location);
cols0 = colobj.Color;
is1    = find( locs0(:,3) > 0);
locs  = locs0(is1,:);
cols  = cols0(is1,:);

%-------------------------------------------------------------------------------
% Take 90% of the convex hull to do image processing analysis on
K    = convhull(locs(:,1),locs(:,2));
bps_cnvh = locs(K,:);
in     = inpolygon(locs(:,1),locs(:,2),fac_cnvh*bps_cnvh(:,1),fac_cnvh*bps_cnvh(:,2));
is2    = find(in == 1);
locs   = locs(is2,:);
locs(:,3) = 0;
cols   = cols(is2,:);
prjobj = pointCloud(locs, 'Color', cols);


%-------------------------------------------------------------------------------
% Get a several well-spaced points within the shape
[xm,ym] = meshgrid(linspace(min(fac_cnvh*bps_cnvh(:,1)),max(fac_cnvh*bps_cnvh(:,1)),100),...
    linspace(min(fac_cnvh*bps_cnvh(:,2)),max(fac_cnvh*bps_cnvh(:,2)),100));
xysmp  = [xm(:) ym(:)];
in     = inpolygon(xysmp(:,1),xysmp(:,2),fac_cnvh*bps_cnvh(:,1),fac_cnvh*bps_cnvh(:,2));
xysmp  = xysmp(in==1,:);
[IDX,C] = kmeans(xysmp, Ndirs);
% Get the closest point of the centers to the 3D point cloud
sampdirs = zeros(Ndirs,3);
for n = 1:Ndirs
    [tmp,i] = min(sqrt( (locs0(is1,1)-C(n,1)).^2+(locs0(is1,2)-C(n,2)).^2));
    sampdirs(n,:) = [C(n,:) locs0(is1(i),3)];
end
sampdirs = double(sampdirs);


%-------------------------------------------------------------------------------
% Convert the sample directions back to the original frame and convert them
% to azimuth and elevation angles
sampdirs0 = convert_pts_back(sampdirs,handles,cent0);
azels = zeros(Ndirs,2);
for n = 1:Ndirs
    azels(n,1) = atan2(sampdirs0(n,2),sampdirs0(n,1));
    azels(n,2) = atan2(sampdirs0(n,3),norm(sampdirs0(n,1:2)) );
end
az2        = str2double(get(handles.cur_az,'String'))*pi/180;
el2        = str2double(get(handles.cur_el,'String'))*pi/180;
dists      = sqrt(sum( (azels - repmat([az2 el2],size(azels,1),1)).^2,2));
[sds,sids] = sort(dists,'ascend');
azels      = azels(sids,:);
azels
figure
set(gcf,'position',[258         213        1025         739])
hold on
pcshow(colobj,'Markersize',MS);
plot3(fac_cnvh*bps_cnvh(:,1),fac_cnvh*bps_cnvh(:,2),bps_cnvh(:,3)+0.01,'-r','linewidth',2)
plot3(1.01*sampdirs(:,1),1.01*sampdirs(:,2),1.01*sampdirs(:,3),'.m','markersize',20)
axis equal
view(2)
% %-------------------------------------------------------------------------------
% % Loop through all the directions, apply the image processing technique,
% % and collect all the data
% for n = 1:Ndirs
%     % Rotate the PLY file and points found to the current frame
%     [colobj,tdat,eclks,cent0] = update_PLY_pts(handles,azels(n,:));
%     pts0 = [];
%     %-------------------------------------------------------------------------------
%     % Take the points 3D and only keep those above the z = 0 mark
%     locs0 = double(colobj.Location);
%     cols0 = colobj.Color;
%     if median(locs0(:,3)) > 0    
%         is1   = find( locs0(:,3) > 0);
%     else
%         is1   = find( locs0(:,3) < 0);
%     end
%     locs  = locs0(is1,:);
%     cols  = cols0(is1,:);
%     if size(pts0,1) > 0
%         is1b   = find( pts0(:,3) > 0);
%         pts   = pts0(is1b,:);
%     end
%     
%     %-------------------------------------------------------------------------------
%     % Take 90% of the convex hull to do image processing analysis on
%     K    = convhull(locs(:,1),locs(:,2));
%     in   = inpolygon(locs(:,1),locs(:,2),0.9*locs(K,1),0.9*locs(K,2));
%     is2   = find(in == 1);
%     locs = locs(is2,:);
%     cols = cols(is2,:);
%     cols = mean(cols,2);
%     
%     %-------------------------------------------------------------------------------
%     % Construct a meshgrid of the locations values
%     npx = 1000;
%     xs      = linspace(min(locs(:,1)),max(locs(:,1)),npx);
%     ys      = linspace(min(locs(:,2)),max(locs(:,2)),npx);
%     [xm,ym] = meshgrid(xs,ys);
%     xys     = [xm(:) ym(:)];
%     
%     %-------------------------------------------------------------------------------
%     % Interpolate onto the meshgrid
%     F     = scatteredInterpolant(locs(:,1:2),cols,'linear','none');
%     img_v = F(xys);
%     img_m = reshape(img_v,size(xm,1),size(xm,2));
%     
%     figure
%     set(gcf,'position',[258         213        1025         739])
%     imagesc(img_m)
%     colormap gray
%     axis equal
%     set(gca, 'YDir','normal')
%     title(['Az=',num2str(round(azels(n,1)*180/pi)),' El=',num2str(round(azels(n,2)*180/pi))])
%     drawnow
% end
% 
% 
% clear


%-------------------------------------------------------------------------------
% Loop through all the directions, apply the image processing technique,
% and collect all the data
newtdats0 = [];
for n = 1:Ndirs
    % Rotate the PLY file and points found to the current frame
    [colobj,tdat,eclks,cent0] = update_PLY_pts(handles,azels(n,:));
    %---------------------------------------------------------------------------
    % Check that the direction is sensical: If most of the points are
    % negative than we really want az+180. If it is flipped, change the
    % azimuth angle and re-transform the point cloud. 
    if median(double(colobj.Location(:,3))) < 0
        azels(n,1) = azels(n,1) +pi;
        [colobj,tdat,eclks,cent0] = update_PLY_pts(handles,azels(n,:));
    end
        
    if size(newtdats0,1) > 0
        newtdats = rotate_general_pts(newtdats0,handles,azels(n,:));
    else
        newtdats = [];
    end
    % Get new points
    [tdats]   = run_prj_alg_v2(colobj,newtdats,dbg_flg);
    if size(tdats,1) > 0
        tdats     = convert_pts_back(tdats,handles,cent0,azels(n,:));
        % Add the points (in the original frame) to the full set of points
        newtdats0         = [newtdats0; tdats];
    end
    % if dbg_flg == 1
    title(['Az=',num2str(round(azels(n,1)*180/pi)),' El=',num2str(round(azels(n,2)*180/pi))])
    drawnow
    % end
end

% %-------------------------------------------------------------------------------
% % To check that it worked...
% handles.eclks = (1.02*sampdirs0);
% update_ptcld_plot(hObject,handles)

%-------------------------------------------------------------------------------
figure
set(gcf,'position',[258         213        1025         739])
hold on
az2        = str2double(get(handles.cur_az,'String'))*pi/180;
el2        = str2double(get(handles.cur_el,'String'))*pi/180;
[colobj,tdat,eclks,cent0] = update_PLY_pts(handles,[az2 el2]);
newtdats = rotate_general_pts(newtdats0,handles,[az2 el2]);
pcshow(colobj,'Markersize',MS);
plot3(1.01*newtdats(:,1),1.01*newtdats(:,2),1.01*newtdats(:,3),'.m','markersize',20)
axis equal
view(2)
