function eclks = find_circles_2Dprj_func(colobj,org,cur_az,cur_el,dbg_flg)

%-------------------------------------------------------------------------------
% Construct the handles structure array
handles.org_x  = org(1);
handles.org_y  = org(2);
handles.org_z  = org(3);    
handles.colobj = colobj;
handles.ini_rz = 0;
handles.ini_rx = 90;
handles.cur_az = cur_az; % 180;
handles.cur_el = cur_el; % 0;
handles.plotplane = 1;
handles.zpl_z  = 0;

%-------------------------------------------------------------------------------
[colobj,tdat,eclks,cent0] = update_PLY_pts_notGUI(handles);

%-------------------------------------------------------------------------------
if dbg_flg == 1
    figure
    pcshow(colobj,'Markersize',MS);
    axis equal
    grid on
    box on
    FS = 12;
    xlabel('X','fontsize',FS,'FontName','times')
    ylabel('Y','fontsize',FS,'FontName','times')
    set(gca,'FontSize',FS,'FontName','times')
    view(2)
end

%-------------------------------------------------------------------------------
% Interpolate to 2D, do image processing, and convert back to 3D
pts3D = prj2D_imganalysis(colobj,1);

%-------------------------------------------------------------------------------
% Transform the points back to the original frame
el2  = handles.cur_el*pi/180;
Rx   = [1 0 0; 0 cos(el2) -sin(el2); 0 sin(el2) cos(el2)];
newp = (Rx')*(pts3D');
az2  = handles.cur_az*pi/180;
Rz   = [cos(az2) sin(az2) 0;-sin(az2) cos(az2) 0; 0 0 1];
newp = (Rz')*newp;
newp = newp + repmat(org',1,size(newp,2));
%-----------------------------------------------------------------------
% Rotate the STL to the initial frame
az   = handles.ini_rz*pi/180;
el   = handles.ini_rx*pi/180;
Rz   = [cos(az) sin(az) 0;-sin(az) cos(az) 0; 0 0 1];
newp = (Rz')*newp;
Rx   = [1 0 0; 0 cos(el) -sin(el); 0 sin(el) cos(el)];
newp = (Rx')*newp;
%-------------------------------------------------------------------------------
eclks = (newp + repmat(cent0',1,size(newp,2)))';

